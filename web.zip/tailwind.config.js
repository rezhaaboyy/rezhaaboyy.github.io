/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./public/**/*.{html,js}'],
  theme: {
    container: {
      center: true,
      padding: '16px',
    },
    extend: {
      color: {
        primary: '#14b8a6',
        dark: '#0f172a',
      },
      screens: {
      '2xl' : '1320px',
      },
    },
  },
  plugins: [],
}

